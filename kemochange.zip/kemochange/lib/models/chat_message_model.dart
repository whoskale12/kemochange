enum MessageSender { user, bot }

class ChatMessageModel {
  final String id;
  final String text;
  final MessageSender sender;
  final DateTime timestamp;

  const ChatMessageModel({
    required this.id,
    required this.text,
    required this.sender,
    required this.timestamp,
  });

  factory ChatMessageModel.fromMap(Map<String, dynamic> map) {
    return ChatMessageModel(
      id: map['id'] as String,
      text: map['text'] as String,
      sender: _senderFromString(map['sender'] as String),
      timestamp: DateTime.parse(map['timestamp'] as String),
    );
  }

  Map<String, dynamic> toMap() => {
    'id': id,
    'text': text,
    'sender': sender == MessageSender.user ? 'user' : 'bot',
    'timestamp': timestamp.toIso8601String(),
  };

  static MessageSender _senderFromString(String v) {
    switch (v) {
      case 'user':
        return MessageSender.user;
      default:
        return MessageSender.bot;
    }
  }
}
