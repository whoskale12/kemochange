class CurrencyModel {
  final String code;
  final String name;
  final String flag;
  final String symbol;

  const CurrencyModel({
    required this.code,
    required this.name,
    required this.flag,
    required this.symbol,
  });

  factory CurrencyModel.fromMap(Map<String, dynamic> map) {
    return CurrencyModel(
      code: map['code'] as String,
      name: map['name'] as String,
      flag: map['flag'] as String,
      symbol: map['symbol'] as String,
    );
  }

  Map<String, dynamic> toMap() => {
    'code': code,
    'name': name,
    'flag': flag,
    'symbol': symbol,
  };

  static final List<Map<String, dynamic>> popularCurrenciesMaps = [
    {'code': 'USD', 'name': 'US Dollar', 'flag': '🇺🇸', 'symbol': '\$'},
    {'code': 'EUR', 'name': 'Euro', 'flag': '🇪🇺', 'symbol': '€'},
    {'code': 'GBP', 'name': 'British Pound', 'flag': '🇬🇧', 'symbol': '£'},
    {'code': 'JPY', 'name': 'Japanese Yen', 'flag': '🇯🇵', 'symbol': '¥'},
    {
      'code': 'IDR',
      'name': 'Indonesian Rupiah',
      'flag': '🇮🇩',
      'symbol': 'Rp',
    },
    {
      'code': 'SGD',
      'name': 'Singapore Dollar',
      'flag': '🇸🇬',
      'symbol': 'S\$',
    },
    {
      'code': 'MYR',
      'name': 'Malaysian Ringgit',
      'flag': '🇲🇾',
      'symbol': 'RM',
    },
    {
      'code': 'AUD',
      'name': 'Australian Dollar',
      'flag': '🇦🇺',
      'symbol': 'A\$',
    },
    {
      'code': 'CAD',
      'name': 'Canadian Dollar',
      'flag': '🇨🇦',
      'symbol': 'CA\$',
    },
    {'code': 'CHF', 'name': 'Swiss Franc', 'flag': '🇨🇭', 'symbol': 'Fr'},
    {'code': 'CNY', 'name': 'Chinese Yuan', 'flag': '🇨🇳', 'symbol': '¥'},
    {
      'code': 'HKD',
      'name': 'Hong Kong Dollar',
      'flag': '🇭🇰',
      'symbol': 'HK\$',
    },
    {'code': 'KRW', 'name': 'South Korean Won', 'flag': '🇰🇷', 'symbol': '₩'},
    {'code': 'INR', 'name': 'Indian Rupee', 'flag': '🇮🇳', 'symbol': '₹'},
    {'code': 'THB', 'name': 'Thai Baht', 'flag': '🇹🇭', 'symbol': '฿'},
    {'code': 'PHP', 'name': 'Philippine Peso', 'flag': '🇵🇭', 'symbol': '₱'},
    {'code': 'VND', 'name': 'Vietnamese Dong', 'flag': '🇻🇳', 'symbol': '₫'},
    {'code': 'BRL', 'name': 'Brazilian Real', 'flag': '🇧🇷', 'symbol': 'R\$'},
    {'code': 'MXN', 'name': 'Mexican Peso', 'flag': '🇲🇽', 'symbol': 'MX\$'},
    {'code': 'SAR', 'name': 'Saudi Riyal', 'flag': '🇸🇦', 'symbol': '﷼'},
  ];

  static List<CurrencyModel> get popularCurrencies =>
      popularCurrenciesMaps.map(CurrencyModel.fromMap).toList();
}
