class ExchangeRateModel {
  final String baseCurrency;
  final Map<String, double> rates;
  final DateTime lastUpdated;
  final bool isLive;

  const ExchangeRateModel({
    required this.baseCurrency,
    required this.rates,
    required this.lastUpdated,
    required this.isLive,
  });

  factory ExchangeRateModel.fromMap(Map<String, dynamic> map) {
    final ratesRaw = map['rates'] as Map<String, dynamic>? ?? {};
    return ExchangeRateModel(
      baseCurrency: map['baseCurrency'] as String? ?? 'USD',
      rates: ratesRaw.map((k, v) => MapEntry(k, (v as num).toDouble())),
      lastUpdated: map['lastUpdated'] is DateTime
          ? map['lastUpdated'] as DateTime
          : DateTime.parse(map['lastUpdated'] as String),
      isLive: map['isLive'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toMap() => {
    'baseCurrency': baseCurrency,
    'rates': rates,
    'lastUpdated': lastUpdated.toIso8601String(),
    'isLive': isLive,
  };

  double? getRate(String targetCode) => rates[targetCode];

  double convert(double amount, String targetCode) {
    final rate = rates[targetCode];
    if (rate == null) return 0.0;
    return amount * rate;
  }

  // Fallback mock rates based on USD (April 2026 approximate)
  static ExchangeRateModel get fallback => ExchangeRateModel(
    baseCurrency: 'USD',
    rates: const {
      'USD': 1.0,
      'EUR': 0.924,
      'GBP': 0.791,
      'JPY': 154.32,
      'IDR': 16285.0,
      'SGD': 1.348,
      'MYR': 4.714,
      'AUD': 1.558,
      'CAD': 1.382,
      'CHF': 0.899,
      'CNY': 7.241,
      'HKD': 7.784,
      'KRW': 1378.5,
      'INR': 83.97,
      'THB': 35.42,
      'PHP': 58.31,
      'VND': 25420.0,
      'BRL': 5.048,
      'MXN': 17.12,
      'SAR': 3.751,
    },
    lastUpdated: DateTime.now(),
    isLive: false,
  );
}
