import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../models/chat_message_model.dart';
import '../../models/currency_model.dart';
import '../../models/exchange_rate_model.dart';
import '../../services/currency_service.dart';
import '../../theme/app_theme.dart';
import './widgets/converter_card_widget.dart';
import './widgets/draggable_chatbot_widget.dart';
import './widgets/home_app_bar_widget.dart';
import './widgets/popular_rates_widget.dart';
import './widgets/rate_trend_chart_widget.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  // TODO: Replace with [Riverpod/Bloc] for production
  final CurrencyService _service = CurrencyService();

  ExchangeRateModel? _rateModel;
  bool _isLoading = true;
  bool _hasError = false;

  List<CurrencyModel> _currencies = [];
  CurrencyModel? _fromCurrency;
  CurrencyModel? _toCurrency;

  double _inputAmount = 1.0;
  double _convertedAmount = 0.0;
  final TextEditingController _amountController = TextEditingController(
    text: '1',
  );

  // Chatbot state
  bool _chatOpen = false;
  Offset _chatbotPosition = const Offset(0, 0);
  bool _chatbotPositionSet = false;
  final List<ChatMessageModel> _chatMessages = [];
  final TextEditingController _chatInputController = TextEditingController();
  final ScrollController _chatScrollController = ScrollController();

  late final AnimationController _contentController;
  late final Animation<double> _contentFade;
  late final Animation<Offset> _contentSlide;

  @override
  void initState() {
    super.initState();
    _currencies = CurrencyModel.popularCurrencies;
    _fromCurrency = _currencies.firstWhere((c) => c.code == 'USD');
    _toCurrency = _currencies.firstWhere((c) => c.code == 'IDR');

    _contentController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _contentFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _contentController, curve: Curves.easeOutCubic),
    );
    _contentSlide =
        Tween<Offset>(begin: const Offset(0, 0.05), end: Offset.zero).animate(
          CurvedAnimation(
            parent: _contentController,
            curve: Curves.easeOutCubic,
          ),
        );

    _fetchRates();
  }

  Future<void> _fetchRates() async {
    if (!mounted) return;
    setState(() {
      _isLoading = true;
      _hasError = false;
    });
    try {
      final model = await _service.fetchRates(
        base: _fromCurrency?.code ?? 'USD',
      );
      if (!mounted) return;
      setState(() {
        _rateModel = model;
        _isLoading = false;
        _hasError = false;
      });
      _recalculate();
      _contentController.forward(from: 0);
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _hasError = true;
        _rateModel = ExchangeRateModel.fallback;
      });
      _recalculate();
      _contentController.forward(from: 0);
    }
  }

  void _recalculate() {
    if (_rateModel == null || _toCurrency == null) return;
    final result = _rateModel!.convert(_inputAmount, _toCurrency!.code);
    if (mounted) setState(() => _convertedAmount = result);
  }

  void _onAmountChanged(String val) {
    final parsed = double.tryParse(val.replaceAll(',', '')) ?? 0.0;
    setState(() => _inputAmount = parsed);
    _recalculate();
  }

  void _onFromCurrencyChanged(CurrencyModel currency) async {
    setState(() {
      _fromCurrency = currency;
      _isLoading = true;
    });
    final model = await _service.fetchRates(base: currency.code);
    if (!mounted) return;
    setState(() {
      _rateModel = model;
      _isLoading = false;
    });
    _recalculate();
  }

  void _onToCurrencyChanged(CurrencyModel currency) {
    setState(() => _toCurrency = currency);
    _recalculate();
  }

  void _swapCurrencies() {
    HapticFeedback.lightImpact();
    final temp = _fromCurrency;
    setState(() {
      _fromCurrency = _toCurrency;
      _toCurrency = temp;
    });
    _fetchRates();
  }

  // Chatbot helpers
  void _initChatbotPosition(Size screenSize) {
    if (_chatbotPositionSet) return;
    _chatbotPosition = Offset(screenSize.width - 80, screenSize.height - 180);
    _chatbotPositionSet = true;
  }

  void _onChatbotDragUpdate(DragUpdateDetails d) {
    final size = MediaQuery.of(context).size;
    setState(() {
      _chatbotPosition = Offset(
        (_chatbotPosition.dx + d.delta.dx).clamp(0.0, size.width - 64),
        (_chatbotPosition.dy + d.delta.dy).clamp(0.0, size.height - 64),
      );
    });
  }

  void _toggleChat() {
    HapticFeedback.selectionClick();
    setState(() => _chatOpen = !_chatOpen);
    if (!_chatOpen) return;
    if (_chatMessages.isEmpty) {
      _addBotMessage(
        "👋 Hey! I'm Kemo, your currency buddy!\n\nAsk me anything like:\n• \"USD to IDR\"\n• \"How much is 100 EUR in JPY?\"\n• \"What's the best rate today?\"",
      );
    }
  }

  void _addBotMessage(String text) {
    setState(() {
      _chatMessages.add(
        ChatMessageModel(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          text: text,
          sender: MessageSender.bot,
          timestamp: DateTime.now(),
        ),
      );
    });
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_chatScrollController.hasClients) {
        _chatScrollController.animateTo(
          _chatScrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOutCubic,
        );
      }
    });
  }

  void _sendChatMessage(String text) {
    if (text.trim().isEmpty) return;
    setState(() {
      _chatMessages.add(
        ChatMessageModel(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          text: text.trim(),
          sender: MessageSender.user,
          timestamp: DateTime.now(),
        ),
      );
    });
    _chatInputController.clear();
    _processBotReply(text.trim().toLowerCase());
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_chatScrollController.hasClients) {
        _chatScrollController.animateTo(
          _chatScrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOutCubic,
        );
      }
    });
  }

  void _processBotReply(String msg) {
    Future.delayed(const Duration(milliseconds: 600), () {
      if (!mounted) return;
      String reply;

      // Simple keyword matching
      final rates = _rateModel ?? ExchangeRateModel.fallback;
      bool matched = false;

      // Check for "X to Y" pattern
      for (final from in CurrencyModel.popularCurrencies) {
        for (final to in CurrencyModel.popularCurrencies) {
          if (from.code == to.code) continue;
          if (msg.contains(from.code.toLowerCase()) &&
              msg.contains(to.code.toLowerCase())) {
            // Try to get rate: convert 1 from→USD→to
            double? rate;
            if (from.code == rates.baseCurrency) {
              rate = rates.getRate(to.code);
            } else {
              final fromRate = rates.getRate(from.code);
              final toRate = rates.getRate(to.code);
              if (fromRate != null && toRate != null && fromRate != 0) {
                rate = toRate / fromRate;
              }
            }
            if (rate != null) {
              reply =
                  "💱 Right now:\n1 ${from.flag} ${from.code} = ${_formatRate(rate)} ${to.flag} ${to.code}\n\n${_rateModel?.isLive == true ? '✅ Live rate' : '⚠️ Approximate rate (offline)'}";
              _addBotMessage(reply);
              matched = true;
              break;
            }
          }
        }
        if (matched) break;
      }

      if (!matched) {
        if (msg.contains('best') ||
            msg.contains('tip') ||
            msg.contains('advice')) {
          reply =
              "💡 Pro tip: Exchange rates are best in the morning (UTC) when London and New York markets overlap.\n\nAlso, always compare with your bank's rate before exchanging!";
        } else if (msg.contains('hello') ||
            msg.contains('hi') ||
            msg.contains('hey')) {
          reply =
              "😊 Hi there! I'm Kemo.\n\nTry asking me:\n• \"USD to IDR\"\n• \"EUR to JPY\"\n• \"Give me a tip\"";
        } else if (msg.contains('update') || msg.contains('refresh')) {
          reply = _rateModel?.isLive == true
              ? "✅ Rates are live! Last updated: ${_formatTime(_rateModel!.lastUpdated)}"
              : "⚠️ Currently showing cached rates. Pull to refresh for live data.";
        } else {
          final from = _fromCurrency;
          final to = _toCurrency;
          if (from != null && to != null) {
            final rate = rates.getRate(to.code);
            if (rate != null) {
              reply =
                  "📊 Current rate:\n1 ${from.flag} ${from.code} = ${_formatRate(rate)} ${to.flag} ${to.code}\n\nWant to know another pair? Just type like: \"EUR to JPY\"";
            } else {
              reply =
                  "🤔 I didn't catch that. Try: \"USD to IDR\" or \"How much is 50 EUR in GBP?\"";
            }
          } else {
            reply =
                "🤔 I didn't catch that. Try: \"USD to IDR\" or \"How much is 50 EUR in GBP?\"";
          }
        }
        _addBotMessage(reply);
      }
    });
  }

  String _formatRate(double rate) {
    if (rate >= 1000) return rate.toStringAsFixed(0);
    if (rate >= 10) return rate.toStringAsFixed(2);
    return rate.toStringAsFixed(4);
  }

  String _formatTime(DateTime dt) {
    final h = dt.hour.toString().padLeft(2, '0');
    final m = dt.minute.toString().padLeft(2, '0');
    return '$h:$m';
  }

  @override
  void dispose() {
    _amountController.dispose();
    _chatInputController.dispose();
    _chatScrollController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final isTablet = size.width >= 600;
    _initChatbotPosition(size);

    return Scaffold(
      backgroundColor: AppTheme.background,
      body: SafeArea(
        child: Stack(
          children: [
            Center(
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  maxWidth: isTablet ? 560 : double.infinity,
                ),
                child: RefreshIndicator(
                  color: AppTheme.primary,
                  onRefresh: _fetchRates,
                  child: CustomScrollView(
                    physics: const AlwaysScrollableScrollPhysics(),
                    slivers: [
                      // App bar
                      SliverToBoxAdapter(
                        child: HomeAppBarWidget(
                          isLive: _rateModel?.isLive ?? false,
                          isLoading: _isLoading,
                          onRefresh: _fetchRates,
                        ),
                      ),
                      SliverToBoxAdapter(
                        child: FadeTransition(
                          opacity: _contentFade,
                          child: SlideTransition(
                            position: _contentSlide,
                            child: Column(
                              children: [
                                const SizedBox(height: 8),
                                // Converter card
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 20,
                                  ),
                                  child: ConverterCardWidget(
                                    currencies: _currencies,
                                    fromCurrency: _fromCurrency,
                                    toCurrency: _toCurrency,
                                    inputAmount: _inputAmount,
                                    convertedAmount: _convertedAmount,
                                    amountController: _amountController,
                                    isLoading: _isLoading,
                                    onAmountChanged: _onAmountChanged,
                                    onFromCurrencyChanged:
                                        _onFromCurrencyChanged,
                                    onToCurrencyChanged: _onToCurrencyChanged,
                                    onSwap: _swapCurrencies,
                                  ),
                                ),
                                const SizedBox(height: 24),
                                // Rate trend chart
                                if (_rateModel != null && !_isLoading)
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 20,
                                    ),
                                    child: RateTrendChartWidget(
                                      fromCurrency: _fromCurrency,
                                      toCurrency: _toCurrency,
                                      currentRate:
                                          _rateModel!.getRate(
                                            _toCurrency?.code ?? 'IDR',
                                          ) ??
                                          0,
                                      service: _service,
                                    ),
                                  ),
                                const SizedBox(height: 24),
                                // Popular rates
                                PopularRatesWidget(
                                  rateModel: _rateModel,
                                  isLoading: _isLoading,
                                  currencies: _currencies,
                                  onPairTap: (from, to) {
                                    _onFromCurrencyChanged(from);
                                    _onToCurrencyChanged(to);
                                  },
                                ),
                                // Bottom padding for chatbot
                                const SizedBox(height: 100),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            // Draggable chatbot
            DraggableChatbotWidget(
              position: _chatbotPosition,
              chatOpen: _chatOpen,
              messages: _chatMessages,
              chatInputController: _chatInputController,
              chatScrollController: _chatScrollController,
              onDragUpdate: _onChatbotDragUpdate,
              onToggleChat: _toggleChat,
              onSendMessage: _sendChatMessage,
            ),
          ],
        ),
      ),
    );
  }
}
