import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../models/currency_model.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/loading_skeleton_widget.dart';
import './currency_selector_widget.dart';

class ConverterCardWidget extends StatefulWidget {
  final List<CurrencyModel> currencies;
  final CurrencyModel? fromCurrency;
  final CurrencyModel? toCurrency;
  final double inputAmount;
  final double convertedAmount;
  final TextEditingController amountController;
  final bool isLoading;
  final ValueChanged<String> onAmountChanged;
  final ValueChanged<CurrencyModel> onFromCurrencyChanged;
  final ValueChanged<CurrencyModel> onToCurrencyChanged;
  final VoidCallback onSwap;

  const ConverterCardWidget({
    super.key,
    required this.currencies,
    required this.fromCurrency,
    required this.toCurrency,
    required this.inputAmount,
    required this.convertedAmount,
    required this.amountController,
    required this.isLoading,
    required this.onAmountChanged,
    required this.onFromCurrencyChanged,
    required this.onToCurrencyChanged,
    required this.onSwap,
  });

  @override
  State<ConverterCardWidget> createState() => _ConverterCardWidgetState();
}

class _ConverterCardWidgetState extends State<ConverterCardWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _swapController;
  late Animation<double> _swapRotation;

  @override
  void initState() {
    super.initState();
    _swapController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _swapRotation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _swapController, curve: Curves.easeOutBack),
    );
  }

  @override
  void dispose() {
    _swapController.dispose();
    super.dispose();
  }

  void _handleSwap() {
    _swapController.forward(from: 0);
    widget.onSwap();
  }

  String _formatConverted(double v) {
    if (v == 0) return '0.00';
    if (v >= 1000000) {
      return v
          .toStringAsFixed(0)
          .replaceAllMapped(
            RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'),
            (m) => '${m[1]},',
          );
    }
    if (v >= 1000) {
      final s = v.toStringAsFixed(2);
      return s.replaceAllMapped(
        RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'),
        (m) => '${m[1]},',
      );
    }
    if (v >= 1) return v.toStringAsFixed(4);
    return v.toStringAsFixed(6);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.border, width: 1.5),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Row(
              children: [
                Text(
                  'Convert',
                  style: GoogleFonts.manrope(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.textMuted,
                    letterSpacing: 0.3,
                  ),
                ),
                const Spacer(),
                if (!widget.isLoading)
                  Text(
                    '1 ${widget.fromCurrency?.code ?? '—'} = ${_formatConverted(widget.convertedAmount / (widget.inputAmount == 0 ? 1 : widget.inputAmount))} ${widget.toCurrency?.code ?? '—'}',
                    style: GoogleFonts.manrope(
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                      color: AppTheme.textMuted,
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 20),
            // FROM section
            _SectionLabel(label: 'From'),
            const SizedBox(height: 8),
            Row(
              children: [
                CurrencySelectorWidget(
                  selected: widget.fromCurrency,
                  currencies: widget.currencies,
                  onChanged: widget.onFromCurrencyChanged,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextField(
                    controller: widget.amountController,
                    keyboardType: const TextInputType.numberWithOptions(
                      decimal: true,
                    ),
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*')),
                    ],
                    onChanged: widget.onAmountChanged,
                    textAlign: TextAlign.right,
                    style: GoogleFonts.manrope(
                      fontSize: 28,
                      fontWeight: FontWeight.w800,
                      color: AppTheme.textPrimary,
                      fontFeatures: const [FontFeature.tabularFigures()],
                    ),
                    decoration: InputDecoration(
                      hintText: '0',
                      hintStyle: GoogleFonts.manrope(
                        fontSize: 28,
                        fontWeight: FontWeight.w800,
                        color: AppTheme.textMuted,
                      ),
                      border: InputBorder.none,
                      enabledBorder: InputBorder.none,
                      focusedBorder: InputBorder.none,
                      contentPadding: EdgeInsets.zero,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              widget.fromCurrency?.name ?? '',
              style: GoogleFonts.manrope(
                fontSize: 11,
                color: AppTheme.textMuted,
                fontWeight: FontWeight.w400,
              ),
            ),
            const SizedBox(height: 16),
            // Divider with swap button
            Row(
              children: [
                Expanded(child: Container(height: 1, color: AppTheme.border)),
                const SizedBox(width: 12),
                GestureDetector(
                  onTap: _handleSwap,
                  child: RotationTransition(
                    turns: _swapRotation,
                    child: Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: AppTheme.primaryMuted,
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: AppTheme.primary.withAlpha(77),
                          width: 1.5,
                        ),
                      ),
                      child: const Icon(
                        Icons.swap_vert_rounded,
                        color: AppTheme.primaryDark,
                        size: 20,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(child: Container(height: 1, color: AppTheme.border)),
              ],
            ),
            const SizedBox(height: 16),
            // TO section
            _SectionLabel(label: 'To'),
            const SizedBox(height: 8),
            Row(
              children: [
                CurrencySelectorWidget(
                  selected: widget.toCurrency,
                  currencies: widget.currencies,
                  onChanged: widget.onToCurrencyChanged,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: widget.isLoading
                      ? const Align(
                          alignment: Alignment.centerRight,
                          child: LoadingSkeletonWidget(
                            width: 140,
                            height: 36,
                            borderRadius: 8,
                          ),
                        )
                      : AnimatedSwitcher(
                          duration: const Duration(milliseconds: 300),
                          transitionBuilder: (child, anim) =>
                              FadeTransition(opacity: anim, child: child),
                          child: Text(
                            _formatConverted(widget.convertedAmount),
                            key: ValueKey(widget.convertedAmount),
                            textAlign: TextAlign.right,
                            style: GoogleFonts.manrope(
                              fontSize: 28,
                              fontWeight: FontWeight.w800,
                              color: AppTheme.primary,
                              fontFeatures: const [
                                FontFeature.tabularFigures(),
                              ],
                            ),
                          ),
                        ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              widget.toCurrency?.name ?? '',
              style: GoogleFonts.manrope(
                fontSize: 11,
                color: AppTheme.textMuted,
                fontWeight: FontWeight.w400,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String label;
  const _SectionLabel({required this.label});

  @override
  Widget build(BuildContext context) {
    return Text(
      label.toUpperCase(),
      style: GoogleFonts.manrope(
        fontSize: 10,
        fontWeight: FontWeight.w700,
        color: AppTheme.textMuted,
        letterSpacing: 0.8,
      ),
    );
  }
}
