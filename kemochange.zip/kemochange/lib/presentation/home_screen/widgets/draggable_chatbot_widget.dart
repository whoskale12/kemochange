import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../models/chat_message_model.dart';
import '../../../theme/app_theme.dart';

class DraggableChatbotWidget extends StatefulWidget {
  final Offset position;
  final bool chatOpen;
  final List<ChatMessageModel> messages;
  final TextEditingController chatInputController;
  final ScrollController chatScrollController;
  final ValueChanged<DragUpdateDetails> onDragUpdate;
  final VoidCallback onToggleChat;
  final ValueChanged<String> onSendMessage;

  const DraggableChatbotWidget({
    super.key,
    required this.position,
    required this.chatOpen,
    required this.messages,
    required this.chatInputController,
    required this.chatScrollController,
    required this.onDragUpdate,
    required this.onToggleChat,
    required this.onSendMessage,
  });

  @override
  State<DraggableChatbotWidget> createState() => _DraggableChatbotWidgetState();
}

class _DraggableChatbotWidgetState extends State<DraggableChatbotWidget>
    with TickerProviderStateMixin {
  late AnimationController _bounceController;
  late Animation<double> _bounceScale;
  late AnimationController _chatPanelController;
  late Animation<double> _chatPanelScale;
  late Animation<double> _chatPanelOpacity;
  late AnimationController _pulseController;
  late Animation<double> _pulseAnim;

  bool _isDragging = false;

  @override
  void initState() {
    super.initState();

    _bounceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _bounceScale = Tween<double>(begin: 1.0, end: 1.0).animate(
      CurvedAnimation(parent: _bounceController, curve: Curves.elasticOut),
    );

    _chatPanelController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _chatPanelScale = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: _chatPanelController, curve: Curves.easeOutBack),
    );
    _chatPanelOpacity = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _chatPanelController, curve: Curves.easeOut),
    );

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 1.0, end: 1.08).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
  }

  @override
  void didUpdateWidget(DraggableChatbotWidget old) {
    super.didUpdateWidget(old);
    if (widget.chatOpen != old.chatOpen) {
      if (widget.chatOpen) {
        _chatPanelController.forward(from: 0);
      } else {
        _chatPanelController.reverse();
      }
    }
  }

  @override
  void dispose() {
    _bounceController.dispose();
    _chatPanelController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  void _onTap() {
    _bounceController.forward(from: 0);
    widget.onToggleChat();
  }

  Size _chatPanelSize(BuildContext context) {
    final screenW = MediaQuery.of(context).size.width;
    final w = (screenW - 48).clamp(260.0, 320.0);
    return Size(w, 380);
  }

  Offset _chatPanelOffset(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final panel = _chatPanelSize(context);
    final botX = widget.position.dx;
    final botY = widget.position.dy;
    const botSize = 64.0;

    double px = botX - panel.width + botSize;
    double py = botY - panel.height - 12;

    px = px.clamp(8.0, size.width - panel.width - 8);
    py = py.clamp(8.0, size.height - panel.height - 8);
    return Offset(px, py);
  }

  @override
  Widget build(BuildContext context) {
    final panelSize = _chatPanelSize(context);
    final panelOffset = _chatPanelOffset(context);

    return Stack(
      children: [
        // Chat panel
        if (widget.chatOpen)
          Positioned(
            left: panelOffset.dx,
            top: panelOffset.dy,
            child: ScaleTransition(
              scale: _chatPanelScale,
              alignment: Alignment.bottomRight,
              child: FadeTransition(
                opacity: _chatPanelOpacity,
                child: _ChatPanel(
                  width: panelSize.width,
                  height: panelSize.height,
                  messages: widget.messages,
                  inputController: widget.chatInputController,
                  scrollController: widget.chatScrollController,
                  onSend: widget.onSendMessage,
                  onClose: widget.onToggleChat,
                ),
              ),
            ),
          ),
        // Chatbot avatar
        Positioned(
          left: widget.position.dx,
          top: widget.position.dy,
          child: GestureDetector(
            onTap: _onTap,
            onPanUpdate: (d) {
              setState(() => _isDragging = true);
              widget.onDragUpdate(d);
            },
            onPanEnd: (_) => setState(() => _isDragging = false),
            child: ScaleTransition(
              scale: _isDragging
                  ? const AlwaysStoppedAnimation(0.92)
                  : _pulseAnim,
              child: AnimatedBuilder(
                animation: _bounceController,
                builder: (_, child) => child!,
                child: _ChatbotAvatar(chatOpen: widget.chatOpen),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _ChatbotAvatar extends StatelessWidget {
  final bool chatOpen;
  const _ChatbotAvatar({required this.chatOpen});

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Container(
          width: 58,
          height: 58,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF10B981), Color(0xFF059669)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: AppTheme.primary.withAlpha(102),
                blurRadius: 16,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Center(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 200),
              child: chatOpen
                  ? const Icon(
                      Icons.close_rounded,
                      key: ValueKey('close'),
                      color: Colors.white,
                      size: 24,
                    )
                  : const Text(
                      '🤖',
                      key: ValueKey('bot'),
                      style: TextStyle(fontSize: 26),
                    ),
            ),
          ),
        ),
        // Notification dot
        if (!chatOpen)
          Positioned(
            right: 0,
            top: 0,
            child: Container(
              width: 14,
              height: 14,
              decoration: BoxDecoration(
                color: AppTheme.warning,
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 2),
              ),
            ),
          ),
      ],
    );
  }
}

class _ChatPanel extends StatelessWidget {
  final double width;
  final double height;
  final List<ChatMessageModel> messages;
  final TextEditingController inputController;
  final ScrollController scrollController;
  final ValueChanged<String> onSend;
  final VoidCallback onClose;

  const _ChatPanel({
    required this.width,
    required this.height,
    required this.messages,
    required this.inputController,
    required this.scrollController,
    required this.onSend,
    required this.onClose,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: Container(
        width: width,
        height: height,
        decoration: BoxDecoration(
          color: AppTheme.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppTheme.border, width: 1.5),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withAlpha(26),
              blurRadius: 24,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          children: [
            // Header
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: const BoxDecoration(
                color: AppTheme.primaryMuted,
                borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
              ),
              child: Row(
                children: [
                  const Text('🤖', style: TextStyle(fontSize: 20)),
                  const SizedBox(width: 8),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Kemo',
                        style: GoogleFonts.manrope(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: AppTheme.primaryDark,
                        ),
                      ),
                      Text(
                        'Currency Assistant',
                        style: GoogleFonts.manrope(
                          fontSize: 10,
                          color: AppTheme.primary,
                        ),
                      ),
                    ],
                  ),
                  const Spacer(),
                  Container(
                    width: 6,
                    height: 6,
                    decoration: const BoxDecoration(
                      color: AppTheme.success,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    'Online',
                    style: GoogleFonts.manrope(
                      fontSize: 10,
                      color: AppTheme.primaryDark,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
            // Messages
            Expanded(
              child: messages.isEmpty
                  ? Center(
                      child: Text(
                        'Ask me about exchange rates!',
                        style: GoogleFonts.manrope(
                          fontSize: 12,
                          color: AppTheme.textMuted,
                        ),
                      ),
                    )
                  : ListView.builder(
                      controller: scrollController,
                      padding: const EdgeInsets.all(12),
                      itemCount: messages.length,
                      itemBuilder: (context, i) {
                        final msg = messages[i];
                        final isBot = msg.sender == MessageSender.bot;
                        return _MessageBubble(message: msg, isBot: isBot);
                      },
                    ),
            ),
            // Input
            Container(
              padding: const EdgeInsets.fromLTRB(12, 8, 8, 12),
              decoration: const BoxDecoration(
                border: Border(
                  top: BorderSide(color: AppTheme.border, width: 1),
                ),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: inputController,
                      style: GoogleFonts.manrope(
                        fontSize: 13,
                        color: AppTheme.textPrimary,
                      ),
                      decoration: InputDecoration(
                        hintText: 'Ask about rates…',
                        hintStyle: GoogleFonts.manrope(
                          fontSize: 13,
                          color: AppTheme.textMuted,
                        ),
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        focusedBorder: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(vertical: 6),
                        isDense: true,
                      ),
                      onSubmitted: onSend,
                    ),
                  ),
                  const SizedBox(width: 6),
                  GestureDetector(
                    onTap: () {
                      HapticFeedback.lightImpact();
                      onSend(inputController.text);
                    },
                    child: Container(
                      width: 34,
                      height: 34,
                      decoration: const BoxDecoration(
                        color: AppTheme.primary,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.send_rounded,
                        color: Colors.white,
                        size: 16,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MessageBubble extends StatelessWidget {
  final ChatMessageModel message;
  final bool isBot;

  const _MessageBubble({required this.message, required this.isBot});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        mainAxisAlignment: isBot
            ? MainAxisAlignment.start
            : MainAxisAlignment.end,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (isBot) ...[
            const Text('🤖', style: TextStyle(fontSize: 16)),
            const SizedBox(width: 6),
          ],
          Flexible(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: isBot ? AppTheme.surfaceVariant : AppTheme.primary,
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(14),
                  topRight: const Radius.circular(14),
                  bottomLeft: Radius.circular(isBot ? 4 : 14),
                  bottomRight: Radius.circular(isBot ? 14 : 4),
                ),
                border: isBot
                    ? Border.all(color: AppTheme.border, width: 1)
                    : null,
              ),
              child: Text(
                message.text,
                style: GoogleFonts.manrope(
                  fontSize: 12,
                  fontWeight: FontWeight.w400,
                  color: isBot ? AppTheme.textPrimary : Colors.white,
                  height: 1.55,
                ),
              ),
            ),
          ),
          if (!isBot) const SizedBox(width: 6),
        ],
      ),
    );
  }
}
