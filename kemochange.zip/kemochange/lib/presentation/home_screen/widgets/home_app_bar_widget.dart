import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/status_badge_widget.dart';

class HomeAppBarWidget extends StatelessWidget {
  final bool isLive;
  final bool isLoading;
  final VoidCallback onRefresh;

  const HomeAppBarWidget({
    super.key,
    required this.isLive,
    required this.isLoading,
    required this.onRefresh,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 16, 8),
      child: Row(
        children: [
          // Logo pill
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: AppTheme.primary,
              borderRadius: BorderRadius.circular(11),
            ),
            child: const Center(
              child: Text(
                '₿',
                style: TextStyle(
                  fontSize: 19,
                  color: Colors.white,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'KemoChange',
                style: GoogleFonts.manrope(
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                  color: AppTheme.textPrimary,
                  letterSpacing: -0.2,
                ),
              ),
              const SizedBox(height: 1),
              StatusBadgeWidget(
                status: isLoading
                    ? BadgeStatus.warning
                    : isLive
                    ? BadgeStatus.live
                    : BadgeStatus.stale,
                label: isLoading
                    ? 'Fetching...'
                    : isLive
                    ? 'Live rates'
                    : 'Cached rates',
                fontSize: 10,
              ),
            ],
          ),
          const Spacer(),
          // Refresh button
          Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(100),
              onTap: onRefresh,
              child: Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: AppTheme.surface,
                  borderRadius: BorderRadius.circular(100),
                  border: Border.all(color: AppTheme.border, width: 1.5),
                ),
                child: isLoading
                    ? const Padding(
                        padding: EdgeInsets.all(10),
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor: AlwaysStoppedAnimation<Color>(
                            AppTheme.primary,
                          ),
                        ),
                      )
                    : const Icon(
                        Icons.refresh_rounded,
                        size: 20,
                        color: AppTheme.textSecondary,
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
