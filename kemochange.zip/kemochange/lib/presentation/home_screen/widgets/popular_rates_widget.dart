import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../models/currency_model.dart';
import '../../../models/exchange_rate_model.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/loading_skeleton_widget.dart';

class PopularRatesWidget extends StatelessWidget {
  final ExchangeRateModel? rateModel;
  final bool isLoading;
  final List<CurrencyModel> currencies;
  final void Function(CurrencyModel from, CurrencyModel to) onPairTap;

  const PopularRatesWidget({
    super.key,
    required this.rateModel,
    required this.isLoading,
    required this.currencies,
    required this.onPairTap,
  });

  static const List<Map<String, String>> _pairs = [
    {'from': 'USD', 'to': 'IDR'},
    {'from': 'USD', 'to': 'EUR'},
    {'from': 'USD', 'to': 'JPY'},
    {'from': 'EUR', 'to': 'GBP'},
    {'from': 'USD', 'to': 'SGD'},
    {'from': 'USD', 'to': 'MYR'},
    {'from': 'AUD', 'to': 'USD'},
    {'from': 'USD', 'to': 'CNY'},
  ];

  String _formatRate(double v) {
    if (v >= 10000) return v.toStringAsFixed(0);
    if (v >= 1000) return v.toStringAsFixed(0);
    if (v >= 100) return v.toStringAsFixed(2);
    if (v >= 1) return v.toStringAsFixed(4);
    return v.toStringAsFixed(6);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
          child: Row(
            children: [
              Text(
                'Popular Pairs',
                style: GoogleFonts.manrope(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.textPrimary,
                ),
              ),
              const Spacer(),
              Text(
                'Tap to convert',
                style: GoogleFonts.manrope(
                  fontSize: 11,
                  color: AppTheme.textMuted,
                ),
              ),
            ],
          ),
        ),
        SizedBox(
          height: 88,
          child: isLoading
              ? ListView.builder(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  itemCount: 4,
                  itemBuilder: (_, i) => Padding(
                    padding: const EdgeInsets.only(right: 12),
                    child: LoadingSkeletonWidget(
                      width: 130,
                      height: 80,
                      borderRadius: 14,
                    ),
                  ),
                )
              : ListView.builder(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  itemCount: _pairs.length,
                  itemBuilder: (context, i) {
                    final pair = _pairs[i];
                    final fromCode = pair['from']!;
                    final toCode = pair['to']!;
                    final fromCurrency = currencies.firstWhere(
                      (c) => c.code == fromCode,
                      orElse: () => currencies.first,
                    );
                    final toCurrency = currencies.firstWhere(
                      (c) => c.code == toCode,
                      orElse: () => currencies.last,
                    );

                    double? rate;
                    if (rateModel != null) {
                      if (rateModel!.baseCurrency == fromCode) {
                        rate = rateModel!.getRate(toCode);
                      } else {
                        final fromRate = rateModel!.getRate(fromCode);
                        final toRate = rateModel!.getRate(toCode);
                        if (fromRate != null &&
                            toRate != null &&
                            fromRate != 0) {
                          rate = toRate / fromRate;
                        }
                      }
                    }

                    // Slight fake variance for visual interest
                    final changeList = [
                      0.12,
                      -0.34,
                      0.08,
                      -0.21,
                      0.45,
                      -0.09,
                      0.17,
                      -0.38,
                    ];
                    final change = changeList[i % changeList.length];
                    final isUp = change >= 0;

                    return GestureDetector(
                      onTap: () => onPairTap(fromCurrency, toCurrency),
                      child: Container(
                        width: 130,
                        margin: const EdgeInsets.only(right: 10),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: AppTheme.surface,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: AppTheme.border,
                            width: 1.5,
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Text(
                                  fromCurrency.flag,
                                  style: const TextStyle(fontSize: 14),
                                ),
                                const SizedBox(width: 2),
                                const Icon(
                                  Icons.arrow_forward_rounded,
                                  size: 10,
                                  color: AppTheme.textMuted,
                                ),
                                const SizedBox(width: 2),
                                Text(
                                  toCurrency.flag,
                                  style: const TextStyle(fontSize: 14),
                                ),
                                const Spacer(),
                                Icon(
                                  isUp
                                      ? Icons.arrow_drop_up_rounded
                                      : Icons.arrow_drop_down_rounded,
                                  size: 16,
                                  color: isUp
                                      ? AppTheme.success
                                      : AppTheme.error,
                                ),
                              ],
                            ),
                            const SizedBox(height: 6),
                            Text(
                              '$fromCode/$toCode',
                              style: GoogleFonts.manrope(
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                color: AppTheme.textSecondary,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              rate != null ? _formatRate(rate) : '—',
                              style: GoogleFonts.manrope(
                                fontSize: 14,
                                fontWeight: FontWeight.w800,
                                color: AppTheme.textPrimary,
                                fontFeatures: const [
                                  FontFeature.tabularFigures(),
                                ],
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 1),
                            Text(
                              '${isUp ? '+' : ''}${change.toStringAsFixed(2)}%',
                              style: GoogleFonts.manrope(
                                fontSize: 10,
                                fontWeight: FontWeight.w600,
                                color: isUp ? AppTheme.success : AppTheme.error,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }
}
