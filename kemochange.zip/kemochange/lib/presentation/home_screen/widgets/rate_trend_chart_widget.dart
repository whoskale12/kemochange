import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../models/currency_model.dart';
import '../../../services/currency_service.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/loading_skeleton_widget.dart';

class RateTrendChartWidget extends StatefulWidget {
  final CurrencyModel? fromCurrency;
  final CurrencyModel? toCurrency;
  final double currentRate;
  final CurrencyService service;

  const RateTrendChartWidget({
    super.key,
    required this.fromCurrency,
    required this.toCurrency,
    required this.currentRate,
    required this.service,
  });

  @override
  State<RateTrendChartWidget> createState() => _RateTrendChartWidgetState();
}

class _RateTrendChartWidgetState extends State<RateTrendChartWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _lineController;
  late Animation<double> _lineProgress;
  List<double> _trendData = [];
  int? _touchedIndex;

  static const List<String> _dayLabels = [
    'Mon',
    'Tue',
    'Wed',
    'Thu',
    'Fri',
    'Sat',
    'Today',
  ];

  @override
  void initState() {
    super.initState();
    _lineController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );
    _lineProgress = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _lineController, curve: Curves.easeOutCubic),
    );
    _buildTrend();
  }

  @override
  void didUpdateWidget(RateTrendChartWidget old) {
    super.didUpdateWidget(old);
    if (old.currentRate != widget.currentRate ||
        old.toCurrency?.code != widget.toCurrency?.code) {
      _buildTrend();
    }
  }

  void _buildTrend() {
    if (widget.currentRate <= 0) return;
    setState(() {
      _trendData = widget.service.generateTrendData(widget.currentRate);
    });
    _lineController.forward(from: 0);
  }

  @override
  void dispose() {
    _lineController.dispose();
    super.dispose();
  }

  double get _minY {
    if (_trendData.isEmpty) return 0;
    final min = _trendData.reduce((a, b) => a < b ? a : b);
    return min * 0.97;
  }

  double get _maxY {
    if (_trendData.isEmpty) return 1;
    final max = _trendData.reduce((a, b) => a > b ? a : b);
    return max * 1.03;
  }

  String _formatRate(double v) {
    if (v >= 10000) return '${(v / 1000).toStringAsFixed(1)}k';
    if (v >= 1000) return v.toStringAsFixed(0);
    if (v >= 10) return v.toStringAsFixed(2);
    return v.toStringAsFixed(4);
  }

  @override
  Widget build(BuildContext context) {
    if (_trendData.isEmpty) {
      return const LoadingSkeletonWidget(
        width: double.infinity,
        height: 160,
        borderRadius: 16,
      );
    }

    final isUp = _trendData.last >= _trendData.first;
    final changePercent = _trendData.first == 0
        ? 0.0
        : ((_trendData.last - _trendData.first) / _trendData.first * 100);

    return Container(
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.border, width: 1.5),
      ),
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '7-Day Trend',
                      style: GoogleFonts.manrope(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${widget.fromCurrency?.code ?? '—'} → ${widget.toCurrency?.code ?? '—'}',
                      style: GoogleFonts.manrope(
                        fontSize: 11,
                        color: AppTheme.textMuted,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 4,
                ),
                decoration: BoxDecoration(
                  color: isUp
                      ? const Color(0xFFD1FAE5)
                      : const Color(0xFFFEE2E2),
                  borderRadius: BorderRadius.circular(100),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      isUp
                          ? Icons.trending_up_rounded
                          : Icons.trending_down_rounded,
                      size: 14,
                      color: isUp
                          ? const Color(0xFF059669)
                          : const Color(0xFFDC2626),
                    ),
                    const SizedBox(width: 3),
                    Text(
                      '${changePercent >= 0 ? '+' : ''}${changePercent.toStringAsFixed(2)}%',
                      style: GoogleFonts.manrope(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: isUp
                            ? const Color(0xFF059669)
                            : const Color(0xFFDC2626),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          AnimatedBuilder(
            animation: _lineProgress,
            builder: (context, _) {
              final progress = _lineProgress.value;
              final visibleCount = (progress * _trendData.length).ceil().clamp(
                1,
                _trendData.length,
              );
              final spots = List.generate(
                visibleCount,
                (i) => FlSpot(i.toDouble(), _trendData[i]),
              );
              return SizedBox(
                height: 140,
                child: LineChart(
                  LineChartData(
                    minY: _minY,
                    maxY: _maxY,
                    lineTouchData: LineTouchData(
                      touchCallback: (event, response) {
                        setState(() {
                          _touchedIndex =
                              response?.lineBarSpots?.first.spotIndex;
                        });
                      },
                      touchTooltipData: LineTouchTooltipData(
                        tooltipRoundedRadius: 10,
                        tooltipBgColor: AppTheme.textPrimary,
                        getTooltipItems: (spots) {
                          return spots.map((s) {
                            return LineTooltipItem(
                              _formatRate(s.y),
                              GoogleFonts.manrope(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                color: Colors.white,
                              ),
                            );
                          }).toList();
                        },
                      ),
                    ),
                    gridData: FlGridData(
                      drawVerticalLine: false,
                      horizontalInterval: (_maxY - _minY) / 3,
                      getDrawingHorizontalLine: (_) => FlLine(
                        color: AppTheme.border,
                        strokeWidth: 1,
                        dashArray: [4, 4],
                      ),
                    ),
                    borderData: FlBorderData(show: false),
                    titlesData: FlTitlesData(
                      leftTitles: const AxisTitles(
                        sideTitles: SideTitles(showTitles: false),
                      ),
                      topTitles: const AxisTitles(
                        sideTitles: SideTitles(showTitles: false),
                      ),
                      rightTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,
                          reservedSize: 44,
                          getTitlesWidget: (v, meta) {
                            if (v == meta.min || v == meta.max) {
                              return Text(
                                _formatRate(v),
                                style: GoogleFonts.manrope(
                                  fontSize: 9,
                                  color: AppTheme.textMuted,
                                  fontFeatures: const [
                                    FontFeature.tabularFigures(),
                                  ],
                                ),
                              );
                            }
                            return const SizedBox.shrink();
                          },
                        ),
                      ),
                      bottomTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,
                          reservedSize: 22,
                          getTitlesWidget: (v, _) {
                            final idx = v.toInt();
                            if (idx < 0 || idx >= _dayLabels.length) {
                              return const SizedBox.shrink();
                            }
                            return Text(
                              _dayLabels[idx],
                              style: GoogleFonts.manrope(
                                fontSize: 9,
                                color: idx == 6
                                    ? AppTheme.primary
                                    : AppTheme.textMuted,
                                fontWeight: idx == 6
                                    ? FontWeight.w700
                                    : FontWeight.w400,
                              ),
                            );
                          },
                        ),
                      ),
                    ),
                    lineBarsData: [
                      LineChartBarData(
                        spots: spots,
                        isCurved: true,
                        curveSmoothness: 0.3,
                        color: isUp ? AppTheme.primary : AppTheme.error,
                        barWidth: 2.5,
                        dotData: FlDotData(
                          show: true,
                          getDotPainter: (spot, _, __, idx) {
                            final isLast = idx == spots.length - 1;
                            final isTouched = idx == _touchedIndex;
                            return FlDotCirclePainter(
                              radius: isLast || isTouched ? 5 : 0,
                              color: isUp ? AppTheme.primary : AppTheme.error,
                              strokeWidth: 2,
                              strokeColor: AppTheme.surface,
                            );
                          },
                        ),
                        belowBarData: BarAreaData(
                          show: true,
                          gradient: LinearGradient(
                            colors: [
                              (isUp ? AppTheme.primary : AppTheme.error)
                                  .withAlpha(46),
                              (isUp ? AppTheme.primary : AppTheme.error)
                                  .withAlpha(0),
                            ],
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}