import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../routes/app_routes.dart';
import '../../theme/app_theme.dart';
import './widgets/onboarding_dot_indicator_widget.dart';
import './widgets/onboarding_page_widget.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen>
    with TickerProviderStateMixin {
  // TODO: Replace with [Riverpod/Bloc] for production
  final PageController _pageController = PageController();
  int _currentPage = 0;

  late final AnimationController _fadeController;
  late final Animation<double> _fadeAnimation;
  late final AnimationController _wordmarkController;
  late final Animation<double> _wordmarkScale;
  late final Animation<double> _wordmarkOpacity;

  static const List<Map<String, dynamic>> _pages = [
    {
      'emoji': '💱',
      'title': 'Instant Conversion',
      'subtitle':
          'Convert between 20+ currencies in real time.\nJust type — results appear instantly.',
      'accent': Color(0xFF10B981),
      'bg': Color(0xFFF0FDF4),
    },
    {
      'emoji': '📡',
      'title': 'Live Exchange Rates',
      'subtitle':
          'Powered by real-time market data.\nAlways know the exact rate before you exchange.',
      'accent': Color(0xFF0EA5E9),
      'bg': Color(0xFFF0F9FF),
    },
    {
      'emoji': '🤖',
      'title': 'Meet Kemo',
      'subtitle':
          'Your draggable currency assistant.\nAsk for rates, tips, or quick conversions — anytime.',
      'accent': Color(0xFF8B5CF6),
      'bg': Color(0xFFF5F3FF),
    },
  ];

  @override
  void initState() {
    super.initState();
    _wordmarkController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );
    _wordmarkScale = Tween<double>(begin: 0.7, end: 1.0).animate(
      CurvedAnimation(parent: _wordmarkController, curve: Curves.easeOutCubic),
    );
    _wordmarkOpacity = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _wordmarkController,
        curve: const Interval(0.0, 0.7, curve: Curves.easeOut),
      ),
    );

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 350),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeOutCubic),
    );

    _wordmarkController.forward().then((_) => _fadeController.forward());
  }

  @override
  void dispose() {
    _pageController.dispose();
    _fadeController.dispose();
    _wordmarkController.dispose();
    super.dispose();
  }

  void _onPageChanged(int index) {
    setState(() => _currentPage = index);
  }

  void _goToNext() {
    if (_currentPage < _pages.length - 1) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 380),
        curve: Curves.easeOutCubic,
      );
    } else {
      _navigateHome();
    }
  }

  void _navigateHome() {
    Navigator.pushNamedAndRemoveUntil(
      context,
      AppRoutes.homeScreen,
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final isTablet = size.width >= 600;
    final accent =
        (_pages[_currentPage]['accent'] as Color?) ?? AppTheme.primary;

    return Scaffold(
      backgroundColor:
          (_pages[_currentPage]['bg'] as Color?) ?? const Color(0xFFF0FDF4),
      body: AnimatedContainer(
        duration: const Duration(milliseconds: 400),
        curve: Curves.easeOutCubic,
        color:
            (_pages[_currentPage]['bg'] as Color?) ?? const Color(0xFFF0FDF4),
        child: SafeArea(
          child: Center(
            child: ConstrainedBox(
              constraints: BoxConstraints(
                maxWidth: isTablet ? 480 : double.infinity,
              ),
              child: Column(
                children: [
                  // Wordmark header
                  Padding(
                    padding: const EdgeInsets.fromLTRB(24, 24, 24, 0),
                    child: ScaleTransition(
                      scale: _wordmarkScale,
                      child: FadeTransition(
                        opacity: _wordmarkOpacity,
                        child: Row(
                          children: [
                            Container(
                              width: 36,
                              height: 36,
                              decoration: BoxDecoration(
                                color: AppTheme.primary,
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: const Center(
                                child: Text(
                                  '₿',
                                  style: TextStyle(
                                    fontSize: 18,
                                    color: Colors.white,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Text(
                              'KemoChange',
                              style: GoogleFonts.manrope(
                                fontSize: 20,
                                fontWeight: FontWeight.w800,
                                color: const Color(0xFF0F172A),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  // Page content
                  Expanded(
                    child: FadeTransition(
                      opacity: _fadeAnimation,
                      child: PageView.builder(
                        controller: _pageController,
                        onPageChanged: _onPageChanged,
                        itemCount: _pages.length,
                        itemBuilder: (context, index) {
                          return OnboardingPageWidget(
                            emoji: _pages[index]['emoji'] as String,
                            title: _pages[index]['title'] as String,
                            subtitle: _pages[index]['subtitle'] as String,
                            accent: _pages[index]['accent'] as Color,
                          );
                        },
                      ),
                    ),
                  ),
                  // Bottom controls
                  Padding(
                    padding: const EdgeInsets.fromLTRB(24, 0, 24, 40),
                    child: Column(
                      children: [
                        OnboardingDotIndicatorWidget(
                          count: _pages.length,
                          current: _currentPage,
                          activeColor: accent,
                        ),
                        const SizedBox(height: 32),
                        SizedBox(
                          width: double.infinity,
                          height: 54,
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 300),
                            curve: Curves.easeOutCubic,
                            decoration: BoxDecoration(
                              color: accent,
                              borderRadius: BorderRadius.circular(100),
                            ),
                            child: Material(
                              color: Colors.transparent,
                              child: InkWell(
                                borderRadius: BorderRadius.circular(100),
                                splashColor: Colors.white24,
                                onTap: _goToNext,
                                child: Center(
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        _currentPage < _pages.length - 1
                                            ? 'Next'
                                            : 'Get Started',
                                        style: GoogleFonts.manrope(
                                          fontSize: 15,
                                          fontWeight: FontWeight.w700,
                                          color: Colors.white,
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      Icon(
                                        _currentPage < _pages.length - 1
                                            ? Icons.arrow_forward_rounded
                                            : Icons.rocket_launch_rounded,
                                        color: Colors.white,
                                        size: 18,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        if (_currentPage < _pages.length - 1) ...[
                          const SizedBox(height: 12),
                          GestureDetector(
                            onTap: _navigateHome,
                            child: Text(
                              'Skip',
                              style: GoogleFonts.manrope(
                                fontSize: 13,
                                fontWeight: FontWeight.w500,
                                color: const Color(0xFF94A3B8),
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
