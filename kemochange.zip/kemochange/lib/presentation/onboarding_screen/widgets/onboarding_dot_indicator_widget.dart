import 'package:flutter/material.dart';

class OnboardingDotIndicatorWidget extends StatelessWidget {
  final int count;
  final int current;
  final Color activeColor;

  const OnboardingDotIndicatorWidget({
    super.key,
    required this.count,
    required this.current,
    required this.activeColor,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(count, (i) {
        final isActive = i == current;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 280),
          curve: Curves.easeOutCubic,
          margin: const EdgeInsets.symmetric(horizontal: 4),
          width: isActive ? 24 : 7,
          height: 7,
          decoration: BoxDecoration(
            color: isActive ? activeColor : const Color(0xFFCBD5E1),
            borderRadius: BorderRadius.circular(100),
          ),
        );
      }),
    );
  }
}
