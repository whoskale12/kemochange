import 'package:flutter/material.dart';
import '../presentation/home_screen/home_screen.dart';
import '../presentation/onboarding_screen/onboarding_screen.dart';

class AppRoutes {
  static const String initial = '/';
  static const String homeScreen = '/home-screen';
  static const String onboardingScreen = '/onboarding-screen';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const OnboardingScreen(),
    homeScreen: (context) => const HomeScreen(),
    onboardingScreen: (context) => const OnboardingScreen(),
  };
}
