import 'package:dio/dio.dart';
import '../models/exchange_rate_model.dart';

class CurrencyService {
  // TODO: Replace with [Riverpod/Bloc] for production
  static const String _baseUrl = 'https://open.er-api.com/v6/latest';

  final Dio _dio;

  CurrencyService()
    : _dio = Dio(
        BaseOptions(
          connectTimeout: const Duration(seconds: 10),
          receiveTimeout: const Duration(seconds: 10),
        ),
      );

  Future<ExchangeRateModel> fetchRates({String base = 'USD'}) async {
    try {
      final response = await _dio.get('$_baseUrl/$base');
      if (response.statusCode == 200) {
        final data = response.data as Map<String, dynamic>;
        final ratesRaw = data['rates'] as Map<String, dynamic>;
        return ExchangeRateModel(
          baseCurrency: base,
          rates: ratesRaw.map((k, v) => MapEntry(k, (v as num).toDouble())),
          lastUpdated: DateTime.fromMillisecondsSinceEpoch(
            ((data['time_last_update_unix'] as num?)?.toInt() ?? 0) * 1000,
          ),
          isLive: true,
        );
      }
      return ExchangeRateModel.fallback;
    } on DioException catch (_) {
      return ExchangeRateModel.fallback;
    } catch (_) {
      return ExchangeRateModel.fallback;
    }
  }

  /// Returns a list of 7 fake-but-plausible historical rate points for
  /// the trend chart (API-free, purely illustrative variance).
  List<double> generateTrendData(double currentRate) {
    final variance = currentRate * 0.025;
    final offsets = [-0.8, -1.2, 0.3, 0.7, -0.4, 0.9, 0.0];
    return offsets
        .map((o) => (currentRate + variance * o).clamp(0.0001, double.infinity))
        .toList();
  }
}
