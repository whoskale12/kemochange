import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

enum BadgeStatus { live, stale, error, info, warning }

class StatusBadgeWidget extends StatelessWidget {
  final BadgeStatus status;
  final String label;
  final double fontSize;

  const StatusBadgeWidget({
    super.key,
    required this.status,
    required this.label,
    this.fontSize = 11,
  });

  @override
  Widget build(BuildContext context) {
    final config = _config(status);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: config.$1,
        borderRadius: BorderRadius.circular(100),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 5,
            height: 5,
            decoration: BoxDecoration(color: config.$2, shape: BoxShape.circle),
          ),
          const SizedBox(width: 4),
          Text(
            label,
            style: GoogleFonts.manrope(
              fontSize: fontSize,
              fontWeight: FontWeight.w600,
              color: config.$2,
            ),
          ),
        ],
      ),
    );
  }

  (Color, Color) _config(BadgeStatus s) {
    switch (s) {
      case BadgeStatus.live:
        return (const Color(0xFFD1FAE5), const Color(0xFF059669));
      case BadgeStatus.stale:
        return (const Color(0xFFFEF3C7), const Color(0xFFB45309));
      case BadgeStatus.error:
        return (const Color(0xFFFEE2E2), const Color(0xFFDC2626));
      case BadgeStatus.info:
        return (const Color(0xFFE0F2FE), const Color(0xFF0284C7));
      case BadgeStatus.warning:
        return (const Color(0xFFFEF3C7), const Color(0xFFD97706));
    }
  }
}
